
	<div  id="footerSection">
	<div class="container">
		<div class="row">
			<div class="span3">
				<h5>ACCOUNT</h5>
				<a href="./profile.php">YOUR ACCOUNT</a>
				<a href="./profile.php">PERSONAL INFORMATION</a> 
				<a href="./profile.php">ADDRESSES</a> 
				<a href="./profile.php">ORDER HISTORY</a>
			 </div>
			<div class="span3">
				<h5>INFORMATION</h5>
				<a href="./contact.php">CONTACT</a>  
				<a href="./signup.php">REGISTRATION</a>  
				<a href="#">LEGAL NOTICE</a>  
				<a hr#">TERMS AND CONDITIONS</a> 
				<a hr#">FAQ</a>
			 </div>
			<div class="span3">
				<h5>OUR OFFERS</h5>
				<a href="./index.php">NEW PRODUCTS</a> 
				<a href="#">TOP SELLERS</a>  
				<a href="#">SPECIAL OFFERS</a>  
				<a href="#">MANUFACTURERS</a> 
				<a href="#">SUPPLIERS</a> 
			 </div>
			<div id="socialMedia" class="span3 pull-right">
				<h5>SOCIAL MEDIA </h5>
				<a href="#"><img width="60" height="60" src="images/facebook.png" title="facebook" alt="facebook"/></a>
				<a href="#"><img width="60" height="60" src="images/twitter.png" title="twitter" alt="twitter"/></a>
				<a href="#"><img width="60" height="60" src="images/youtube.png" title="youtube" alt="youtube"/></a>
			 </div> 
		 </div>
	</div><!-- Container End -->
	</div>