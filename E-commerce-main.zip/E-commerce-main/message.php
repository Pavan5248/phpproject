
	<style>
        .mess-cont{
            height:100%;
            display:flex;
        justify-content:center;
        align-items:center;
        flex-direction:column;
        }
    .mess-box{
        display:flex;
        justify-content:center;
        align-items:center;
        flex-direction:column;
        height:70%;
        width:60%;
        box-shadow: 10px 10px 34px 7px rgba(204,247,203,0.75);
-webkit-box-shadow: 10px 10px 34px 7px rgba(204,247,203,0.75);
-moz-box-shadow: 10px 10px 34px 7px rgba(204,247,203,0.75);
    }
    .mess{
        height: clamp(250px,540px,70%);
        display:flex;
        justify-content:center;
        align-items:center;
        flex-direction:column;
    }
</style>
<div class="mess-cont">

<div class="mess-box">
<div class="mess">
    <img  src="./images/thank.png" alt="prod to deliver" style="height:80%;width:100%">
<h3 style="margin-top:0px;padding:0px;color:grey;text-align:center"><span style='color:lime'>Thanks for choosing Electric-shop</span></h3>
<button style="background:aliceblue;padding:5px;text-decoration:none;margin-bottom:20px;border:2px dashed grey"><a href="index.php" style='text-decoration:none'><b> Keep Shopping </b></a> </button>

</div>
</div>
</div>

